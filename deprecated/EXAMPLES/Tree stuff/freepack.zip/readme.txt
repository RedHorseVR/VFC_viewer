4 Free Menu Applets.

View the file "readme.htm" in a web browser
to see more information as a webpage.

Free to non-commercial. Available
cheaply in slightly improved versions
to commercial buyers. Don't forget to
read the licence agreements!

Two of these applets are Gamelan "cool"
award winners. One is a "cool tool of the
day" winner. The set is designed to
cover most small website navigation
needs, and more free applets will be
added on a regular basis.


1. Tab-Tree

Name: "iTree Mini Menu"
File: itfree.zip
More info: http://www.imint.com/itree/itdoc101.htm


2. Buttons

Name: "Magic Buttons"
File: mb104.zip
More info: http://www.imint.com/magic/mb101.htm


3. Pop-up Menu

Name: "iPOP Mini Menu"
File: ipmini206.zip
More info: http://www.imint.com/ipop/ipdoc101.htm


4. Imagemap Menu

Name: "iMMap Mini Imagemap"
File: imfree.zip
More info: http://www.imint.com/immap/imdoc101.htm


