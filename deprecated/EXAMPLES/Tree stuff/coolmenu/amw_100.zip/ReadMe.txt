Applet Menu Wizard 1.0 Readme File

1. Purpose
	Applet Menu Wizard is a powerful tool developed by SourceTec 
	Software Co. Ltd which can automate the tasks configuring the 
	parameters of the CoolMenu(TM) applet.

	CoolMenu is a Java Applet program which implement web navigation
	menu system,and it is developed by SourceTec Software Co. Ltd 
	also.It could be used in web homepages. CoolMenu support both 
	one level and two levels menu system.The one level menu looks 
	like a group of buttons or labels, and the two levels menu 
	looks like a main menu with some sub menus.

2. FEATURES
	* Use wizard to guide configuration step by step
	* Select templates to make work easy
	* Preview CoolMenu that you have just customized

   Who need Applet Menu Wizard?

	* If you are making web page,you want to insert a applet 
	  button or menu into it.
	* If you were boring to configure the button or menu applet's 
	  parameter,you want to have a button or menu applet which 
	  can be configured easily.
	* If you didn't satisfied with your current button or menu 
	  applet,you want to have a button or menu applet which has 
	  powerful capacity.
   
    You have got the solution !

   Features to be added

    * Support multi-level menu system in next version.

3. PLATFORM
   Win95, Win NT 4.0

4. INSTALLATION
   Run "Setup.exe".

6. LICENSE AND REGISTER
   This is a SHAREWARE.
   The unregistered software may be freely copied and distributed
   if no modification is made in the archive package. 

   Check out the license.txt and register.txt for license and 
   register information.

7. CONTACT US
   You can contact SourceTec at: SourceTec@bigfoot.com
