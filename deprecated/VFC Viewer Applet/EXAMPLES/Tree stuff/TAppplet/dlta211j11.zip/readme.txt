
-----------------------------------------------------------------------
TreeApplet 2.11-j11, manual
using Navigator 4.5+, or IE 4.0+
(created january 19, 1999)
-----------------------------------------------------------------------


Copyright (c) 1998-99 Robert Della Malva, rdellamalva@real3d.net
All Rights Reserved.

This release contains the following directories:

example/
images/
manual/

Description of contents:

example  - contains sample codes.
images   - contains images used in the manual.
manual   - contains the reference manual including link to sample codes, and the java applet



Start off:
----------
Open the start.html file in a browser. This contains
links to most of the above and setup instructions.



Troubleshooting:
----------------
Due to Java security restrictions, some applets may not
work on local files, depending on browsers and browsers'versions.

Important notice:
-----------------
Support is given to registered users.

Online help:
------------
http://www.real3d.net/ta211j11help/index.html

-----------------------------------------------------------------------
www.real3d.net
-----------------------------------------------------------------------

-----------------------------------------------------------------------
modified:

february 8, 1999
. added no-java menu

january 25, 1999
. cleaned up directories

january 21, 1999
. added link to the online help
. added status messages

january 20, 1999
. "html, required", warning notice, copyright error.
-----------------------------------------------------------------------
